# cgb-acid-hell
😈 Your Game Boy Color emulator does not pass this test. 😈

## Reference Image
To pass this test an emulator should generate output identical to the image below:

![reference image](img/reference.png)

[Reference photo from a real device](https://github.com/mattcurrie/cgb-acid-hell/raw/main/img/photo.jpg)

## ROM Download
This is not a day care.

## Emulator Requirements
Not telling. 🤫

## Guide
Nope.
