# SameSuite

SameSuite is a set of Game Boy and Game Boy Color test ROMs, developed to aid the development of [SameBoy](https://github.com/LIJI32/SameBoy) by documenting previously unknown hardware behaviors and verifying correct emulation. For more details, read the `README.md` file inside each sub-suite.
